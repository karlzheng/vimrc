################################################################################
#
# file:     vimsh.py
# purpose:  allows execution of shell commands in a vim buffer
#
# author:   brian m sturk   bsturk@comcast.net,
#                           http://home.comcast.net/~bsturk/vim.html
# created:  12/02/01
# last_mod: 02/13/10
# version:  0.22
#
# usage, etc:   see README
# history:      see CHANGELOG
# in the works: see TODO
#
###############################################################################

##  NOTE: If you're having a problem running vimsh, please
##        change the 0 to a 1 for _DEBUG_ and send me an email
##        of the output.

_DEBUG_   = 0

g_buffers = []
g_init_ok = 0
g_use_pty = 1

################################################################################

try:
    import vim, sys, os, string, re, time

    if sys.platform == 'win32':

        import msvcrt, win32process

        from win32file  import ReadFile, WriteFile
        from win32pipe  import PeekNamedPipe
        from subprocess import *

        g_use_pty = 0

    else:
        import pty, tty, select, signal

    vim.command( 'let g:vimsh_loaded_ok = "1"' )
    g_init_ok = 1

except ImportError, e:

    vim.command( 'let g:vimsh_load_error = "' + str( e ) + '"' )
    g_init_ok = 0

################################################################################
##                             class vimsh                                    ##
################################################################################

class vimsh:
    def __init__( self, _sh, _arg, _filename ):

        self.sh       = _sh
        self.arg      = _arg
        self.filename = _filename

        self.prompt_line, self.prompt_cursor = self.get_vim_cursor_pos()

        self.password_regex   = [ '^\s*Password:',         ##  su, ssh, ftp
                                  'password:',             ##  ???, seen this somewhere
                                  'Password required' ]    ##  other ftp clients

        self.shell_exited       = 0
        self.last_cmd_executed  = 'foobar'
        self.buffer             = vim.current.buffer
        self.eof_key            = ''
        self.intr_key           = ''

################################################################################

    def setup_pty( self, _use_pty ):

        self.using_pty = _use_pty

        if _use_pty:

            ##  The lower this number is the more responsive some commands
            ##  may be ( printing prompt, ls ), but also the quicker others
            ##  may timeout reading their output ( ping, ftp )

            self.delay = 0.2

            ##  Hack to get pty name until I can figure out to get name
            ##  of slave pty using pty.fork() I've tried everything
            ##  including using all of the python src for pty.fork().
            ##  I'm probably trying to do something I can't do. However,
            ##  there does seem to be a std call named ptsname() which
            ##  returns the slave pty name i.e. /dev/pty/XX

            ##  Assumption is, that between the dummy call to
            ##  master_open is done and the pty.fork happens, we'll be
            ##  the next pty entry after the one from pty.master_open()
            ##  According to SysV docs it will look for the first
            ##  unused, so this shouldn't be too bad besides its looks.
            ##  Only have to make sure they're not already in use and
            ##  if it is try the next one etc.

            self.master, pty_name = pty.master_open()
            dbg_print ( 'setup_pty: slave pty name is ' + pty_name )

            self.pid, self.fd = pty.fork()      ##  pid and fd are of child shell

            self.outd = self.fd
            self.ind  = self.fd
            self.errd = self.fd

            signal.signal( signal.SIGCHLD, self.sigchld_handler )

            if self.pid == 0:

                ##  In spawned shell process.  NOTE: any 'print'ing done within here will corrupt vim.

                attrs = tty.tcgetattr( 1 )

                attrs[ 6 ][ tty.VMIN ]  = 1
                attrs[ 6 ][ tty.VTIME ] = 0
                attrs[ 0 ] = attrs[ 0 ] | tty.BRKINT
                attrs[ 0 ] = attrs[ 0 ] | tty.IGNBRK
                attrs[ 3 ] = attrs[ 3 ] & ~tty.ICANON & ~tty.ECHO

                tty.tcsetattr( 1, tty.TCSANOW, attrs )

                try:

                    args = [ self.sh ]

                    if self.arg != '':
                        args.append( self.arg )

                    os.execv( self.sh, args )

                except:
                    print( 'setup_pty: Couldn\'t start specified shell ' + self.sh )

            else:

                try:
                    attrs = tty.tcgetattr( 1 )
                    termios_keys = attrs[ 6 ]

                    ##  Get *real* key-sequence for standard input keys, i.e. EOF

                    self.intr_key = termios_keys[ tty.VINTR ]
                    self.eof_key  = termios_keys[ tty.VEOF ]

                except:
                    dbg_print ( 'setup_pty: tcgetattr failed' )

        else:

            ##  Use pipes on Win32. not as reliable/nice. works OK but with limitations.

            self.delay = 0.2

            p = Popen( self.sh + ' ' + self.arg, shell = False, bufsize = 32, stdin = PIPE, stdout = PIPE, stderr = PIPE, creationflags = win32process.CREATE_NO_WINDOW | win32process.CREATE_NEW_PROCESS_GROUP )
            ( self.stdin, self.stdout, self.stderr ) = ( p.stdin, p.stdout, p.stderr )

            self.outd = self.stdout.fileno()
            self.ind  = self.stdin.fileno ()
            self.errd = self.stderr.fileno()
            self.pid  = p.pid

            dbg_print ( 'setup_pty: self.outd: ' + str( self.outd ) )
            dbg_print ( 'setup_pty: self.ind:  ' + str( self.ind ) )
            dbg_print ( 'setup_pty: self.errd: ' + str( self.errd ) )
            dbg_print ( 'setup_pty: pid is     ' + str( self.pid ) )

################################################################################

    def execute_cmd( self, _cmd = None, _null_terminate = 1 ):

        had_non_keyb_exception = 0

        dbg_print ( 'execute_cmd: Entered cmd is ' + str( _cmd ) )

        try:

            ##  This is the main worker function

            print ''            ##  Clears the ex command window

            cur = self.buffer
            cur_line, cur_row = self.get_vim_cursor_pos()

            if _cmd == None:

                ##  Grab everything from the prompt to the current cursor position.

                try:
                    _cmd    = cur[ self.prompt_line - 1 : cur_line ]        # whole line
                    _cmd[0] = _cmd[0][ ( self.prompt_cursor - 1 ) : ]       # remove prompt, zero based slicing

                except:
                    dbg_print( 'Error referencing the current buffer: ' + str( _cmd ) )

            if re.search( r'^\s*\bclear\b', _cmd[0] ) or re.search( r'^\s*\bcls\b', _cmd[0] ):

                dbg_print ( 'execute_cmd: clear detected' )
                self.clear_screen( True )

            elif re.search( r'^\s*\exit\b', _cmd[0] ):

                dbg_print ( 'execute_cmd: exit detected' )
                self.handle_exit_cmd( _cmd )

            else:

                dbg_print ( 'execute_cmd: other command executed' )

                for c in _cmd:
                    if _null_terminate:
                        self.write( c + '\n' )

                    else:
                        self.write( c )

                self.last_cmd_executed = _cmd[0]

                self.end_exe_line()
                vim.command( 'startinsert!' )

        except KeyboardInterrupt:

            dbg_print( 'execute_cmd: in keyboard interrupt exception, got SIGINT' )

        except:            

            ##  Anything else is the shell exiting

            dbg_print( 'execute_cmd: exception' )

            self.handle_shell_exited()

            had_non_keyb_exception = 1

        if not had_non_keyb_exception and self.shell_exited:
            self.handle_shell_exited()

################################################################################

    def end_exe_line( self ):

        ##  read anything that's on stdout after a command is executed

        dbg_print( 'end_exe_line: enter' )

        cur = self.buffer

        cur.append( '' )
        vim.command( 'normal G$' )

        self.read( cur )
        self.check_for_passwd()

################################################################################

    def write( self, _cmd ):

        dbg_print( 'write: writing out --> ' + _cmd )

        if self.using_pty:
            os.write( self.ind, _cmd )

        else:
            osfh = msvcrt.get_osfhandle( self.ind )
            ( errCode, written ) = WriteFile( osfh, _cmd )

################################################################################

    def read( self, _buffer ):

        dbg_print( 'read: entered' )

        num_iterations       = 0      ##  counter for periodic redraw
        iters_before_redraw  = 10
        any_lines_read       = 0      ##  sentinel for reading anything at all

        if not self.using_pty:
            iters_before_redraw = 1 

        while 1:

            if self.using_pty:
                r, w, e = select.select( [ self.outd ], [], [], self.delay )

            else:
                r = [1,]  ##  pipes, unused, fake it out so I don't have to special case

            for file_iter in r:

                output = ''

                if self.using_pty:
                    output = os.read( self.outd, 32 )

                else:
                    output = self.pipe_read( self.outd, 32 )

                if output == '':

                    dbg_print( 'read: No more data on stdout pipe_read' )

                    r = []          ##  sentinel, end of data to read
                    break

                any_output_read = 1 
                num_iterations += 1

                output = self.process_read( output )
                self.print_lines( output, _buffer )

                ##  Give vim a little cpu time, so programs that spit
                ##  output or are long operations seem more responsive

                if not num_iterations % iters_before_redraw:
                    dbg_print( 'read: Letting vim redraw' )
                    vim.command( 'redraw' )

            if r == []:

                dbg_print( 'read: end of data to self.read()' )
                self.end_read( any_lines_read )

                break

################################################################################

    def process_read( self, _output ):

        dbg_print( 'process_read: Raw lines read from stdout:' )
        dbg_print( _output )

        lines_to_print = string.split( _output, '\n' )

        ##  On windows cmd is "echoed" and output sometimes has leading empty line

        if not self.using_pty:

            dbg_print( 'last cmd executed is ' + self.last_cmd_executed )

            m = re.search( re.escape( self.last_cmd_executed.strip() ), lines_to_print[ 0 ] )

            if m != None: 
                
                dbg_print( 'process_read: Win32, removing echo\'ed cmd' )
                lines_to_print = lines_to_print[ 1: ]

            elif lines_to_print[ 0 ] == '':

                dbg_print( 'process_read: Win32, removing leading empty line' )
                lines_to_print = lines_to_print[ 1: ]

        num_lines = len( lines_to_print )

        ##  Split on '\n' sometimes returns n + 1 entries

        if num_lines > 1:
            last_line = lines_to_print[ num_lines - 1 ].strip()

            if last_line == '':
                lines_to_print = lines_to_print[ :-1 ]

        errors = self.chk_stderr()

        if errors:
            dbg_print( 'process_read: Prepending stderr --> ' )
            lines_to_print = errors + lines_to_print

        return lines_to_print

################################################################################

    def print_lines( self, _lines, _buffer ):

        num_lines = len( _lines )

        dbg_print( 'print_lines: Number of lines to print--> ' + str( num_lines ) )

        for line_iter in _lines:

            dbg_print( 'print_lines: Current line is --> %s' % line_iter )

            newlines_removed = 0

            exp = [ '\r$', '\n$' ]

            for e in exp:

                while re.search( e, line_iter ):

                    newlines_removed += 1

                    dbg_print( 'print_lines: removing trailing ^M' )

                    line_iter = line_iter[ :-1 ]   #  Force it

            ##  Jump to the position of the last insertion to the buffer
            ##  if it was a new line it should be 1, if it wasn't
            ##  terminated by a '\n' it should be the end of the string

            vim.command( 'normal ' + str( self.prompt_cursor ) + '|' )

            cur_line, cur_row = self.get_vim_cursor_pos()
            dbg_print( 'print_lines: After jumping to end of last cmd: line %d row %d' % ( cur_line, cur_row ) )

            dbg_print( 'print_lines: Pasting ' + line_iter + ' to current line' )
            _buffer[ cur_line - 1 ] += line_iter

            if self.using_pty:
                for i in range( newlines_removed ):
                    _buffer.append( '' )

            else:
                ##  Windows eats ^M^M and just prints ^M
                if ( newlines_removed ):
                    _buffer.append( '' )

            vim.command( 'normal G$' )
            vim.command( 'startinsert!' )

            self.prompt_line, self.prompt_cursor = self.get_vim_cursor_pos()
            dbg_print( 'print_lines: Saving cursor location: line %d row %d ' % ( self.prompt_line, self.prompt_cursor ) )

################################################################################

    def end_read( self, _any_lines_read ):

        cur_line, cur_row = self.get_vim_cursor_pos( )

        if not self.using_pty and _any_lines_read:

            ##  remove last line for last read only if lines were
            ##  read from stdout.  TODO: any better way to do this?

            vim.command( 'normal dd' )

        vim.command( 'normal G$' )
        vim.command( 'startinsert!' )

        ##  Tuck away location, all data read is in buffer

        self.prompt_line, self.prompt_cursor = self.get_vim_cursor_pos()
        dbg_print( 'end_read: Saving cursor location: line %d row %d ' % ( self.prompt_line, self.prompt_cursor ) )

################################################################################

    def page_output( self, _add_new_line = 0 ):

        dbg_print( 'page_output: enter' )

        ##  read anything that's left on stdout

        cur = self.buffer

        if _add_new_line:

            cur.append( '' )
            vim.command( 'normal G$' )

        self.read( cur )

        self.check_for_passwd()

        vim.command( 'startinsert!' )

################################################################################

    def cleanup( self ):

        ##  NOTE: Only called via autocommand

        dbg_print( 'cleanup: enter' )

        ##  Remove autocommand so we don't get multiple calls

        vim.command( 'au! BufDelete ' + self.filename )

        remove_buf( self.filename )

        try:

            if self.using_pty:
                os.kill( self.pid, signal.SIGKILL )

        except:
            dbg_print( 'cleanup: Exception, process probably already killed' )

################################################################################

    def win32_sig_handler( self, _signal ):

        print 'Got ctrl-c'
        print

################################################################################

    def send_intr( self ):

        dbg_print( 'send_intr: enter' )

        if show_workaround_msgs == '1':
            print 'If you do NOT see a prompt in the vimsh buffer, press ' + page_output_key + ' or Enter'
            print 'If you need a new prompt press ' + new_prompt_key
            print 'NOTE: To disable this help message set \'g:vimsh_show_workaround_msgs\' to 0 in your .vimrc'

        ##  This triggers another KeyboardInterrupt async

        dbg_print( 'send_intr: sending SIGINT' )

        if self.using_pty:
            self.write( self.intr_key )

        try:

            self.page_output( 1 )

        except KeyboardInterrupt:

            dbg_print( 'send_intr: caught KeyboardInterrupt in send_intr' )

################################################################################

    def send_eof( self ):

        dbg_print( 'send_eof: enter' )

        try:     ##  could cause shell to exit

            self.write( self.eof_key )
            self.page_output( 1 )

        except Exception, e:        

            dbg_print( 'send_eof: exception' )

            self.handle_shell_exited()

################################################################################

    def handle_exit_cmd( self, _cmd ):

        ##  Exit was typed, could be the spawned shell, or a subprocess like
        ##  telnet/ssh/etc.

        dbg_print( 'handle_exit_cmd: enter' )

        dbg_print ( 'handle_exit_cmd: writing exit command' )
        self.write( _cmd[0] + '\n' )

        self.end_exe_line()
        vim.command( 'startinsert!' )

################################################################################

    def handle_shell_exited( self ):

        dbg_print( 'handle_shell_exited: enter' )

        ##  when exiting this way can't have the autocommand
        ##  for BufDelete run.  It crashes vim.  TODO:  Figure this out.

        vim.command( 'stopinsert' )
        vim.command( 'au! BufDelete ' + self.filename )
        vim.command( 'bdelete! ' + self.filename )

        remove_buf( self.filename )

################################################################################

    def sigchld_handler( self, _sig, _frame ):

        dbg_print( 'sigchld_handler: caught SIGCHLD' )

        self.waitpid()

################################################################################

    def sigint_handler( self, _sig, _frame ):

        dbg_print( 'sigint_handler: caught SIGINT' )
        dbg_print( '' )

        self.waitpid()

################################################################################

    def waitpid( self ):

        ##  This routine cannot do anything except for marking that the original
        ##  shell process has gone away if it has.  This is due to the async
        ##  nature of signals.

        if os.waitpid( self.pid, os.WNOHANG )[0]:

            self.shell_exited = 1
            dbg_print( 'waitpid: shell exited' )

        else:

            dbg_print( 'waitpid: shell hasn\'t exited, ignoring' )

################################################################################

    def set_timeout( self ):

        timeout_ok = 0

        while not timeout_ok:

            try:
                vim.command( 'let timeout = input( "Enter new timeout in seconds (i.e. 0.1), currently set to ' + str( self.delay ) + ' :  " )' )

            except KeyboardInterrupt:
                return

            timeout = vim.eval( 'timeout' )

            if timeout == '':               ##  usr cancelled dialog, break out
                timeout_ok = 1

            else:
                timeout = float( timeout )
            
                if timeout >= 0.1:
                    print '      --->   New timeout is ' + str( timeout ) + ' seconds'
                    self.delay = timeout
                    timeout_ok = 1

################################################################################

    def clear_screen( self, _in_insert_mode ):

        dbg_print( 'clear_screen: insert mode is ' + str( _in_insert_mode )  )

        self.write( '' + '\n' )    ##  new prompt

        if clear_all == '1':
            vim.command( 'normal ggdG' )

        self.end_exe_line()

        if clear_all == '0':
            vim.command( 'normal zt' )

        if _in_insert_mode:
            vim.command( 'startinsert!' )

        else:
            vim.command( 'stopinsert' )

################################################################################

    def new_prompt( self ):

        self.execute_cmd( [''] )        #  just press enter

        vim.command( 'normal G$' )
        vim.command( 'startinsert!' )

################################################################################

    def get_vim_cursor_pos( self ):

        cur_line, cur_row = vim.current.window.cursor
        
        return cur_line, cur_row + 1

################################################################################

    def check_for_passwd( self ):

        cur_line, cur_row = self.get_vim_cursor_pos()

        prev_line = self.buffer[ cur_line - 1 ]

        for regex in self.password_regex:

            if re.search( regex, prev_line ):

                try:
                    vim.command( 'let password = inputsecret( "Password? " )' )

                except KeyboardInterrupt:
                    return

                password = vim.eval( 'password' )

                self.execute_cmd( [password] )       ##  recursive call here...

################################################################################

    def pipe_read( self, _pipe, _minimum_to_read ):

        ##  Hackaround since Windows doesn't support select() except for sockets.

        dbg_print( 'pipe_read: minimum to read is ' + str( _minimum_to_read ) )
        dbg_print( 'pipe_read: sleeping for ' + str( self.delay ) + ' seconds' )

        time.sleep( self.delay )

        data  = ''
        osfh  = msvcrt.get_osfhandle( _pipe )

        ( read, count, msg ) = PeekNamedPipe( osfh, 0 )

        dbg_print( 'pipe_read: initial count via PeekNamedPipe is ' + str( count ) )

        while ( count > 0 ):

            dbg_print( 'pipe_read: reading from pipe' )
            dbg_print( '' )

            ( err, tmp ) = ReadFile( osfh, count, None )
            data += tmp

            dbg_print( 'pipe_read: read ' + str( tmp ) )

            ( read, count, msg ) = PeekNamedPipe( osfh, 0 )

            ##  Be sure to break the read, if asked to do so,
            ##  after we've read in a line termination.

            if _minimum_to_read != 0 and len( data ) > 0 and data[ len( data ) -1 ] == '\n':

                if len( data ) >= _minimum_to_read:
                    dbg_print( 'pipe_read: found termination and read at least the minimum asked for' )
                    break

                else:
                    dbg_print( 'pipe_read: not all of the data has been read' )

        dbg_print( 'pipe_read: returning' )

        return data

################################################################################

    def chk_stderr( self ):

        errors  = ''
        dbg_print( 'chk_stderr: enter' )

        if not self.using_pty:

            err_txt  = self.pipe_read( self.errd, 0 )
            errors   = string.split( err_txt, '\n' )

            num_lines = len( errors )
            dbg_print( 'chk_stderr: Number of error lines is ' + `num_lines` )

            last_line = errors[ num_lines - 1 ].strip()

            if last_line == '':
                dbg_print( 'chk_stderr: Removing last line, it\'s empty' )
                errors = errors[ :-1 ]

        return errors

################################################################################
##                           Helper functions                                 ##
################################################################################
        
def test_and_set( _vim_var, _default_val ):

    ret = _default_val

    vim.command( 'let dummy = exists( "' + _vim_var + '" )' )
    exists = vim.eval( 'dummy' )

    ##  exists will always be a string representation of the evaluation

    if exists != '0':
        ret = vim.eval( _vim_var )
        dbg_print( 'test_and_set: variable ' + _vim_var + ' exists, using supplied ' + ret )

    else:
        dbg_print( 'test_and_set: variable ' + _vim_var + ' doesn\'t exist, using default ' + ret )

    return ret

################################################################################

def dump_str_as_hex( _str ):

    hex_str = ''

    print 'length of string is ' + str( len( _str ) )

    for x in range( 0, len( _str ) ):
        hex_str = hex_str + hex( ord( _str[x] ) ) + '\n'

    print 'raw line ( hex ) is:'
    print hex_str

################################################################################

def dbg_print( _str ):

    if _DEBUG_:
        print _str

################################################################################

def new_buf( _filename ):

    filename = _filename

    try:

        vim.command( 'let dummy = buflisted( "' + filename + '" )' )
        exists = vim.eval( 'dummy' )

        if exists == '0':
            dbg_print( 'new_buf: buffer ' + filename + ' doesn\'t exist' )

            if split_open == '0':
                vim.command( 'edit ' + filename )

            else:
                vim.command( 'new ' + filename )

            vim.command( 'setlocal buftype=nofile' )
            vim.command( 'setlocal bufhidden=hide' )
            vim.command( 'setlocal noswapfile' )
            vim.command( 'setlocal tabstop=8' )
            vim.command( 'setlocal modifiable' )
            vim.command( 'setlocal nowrap' )
            vim.command( 'setlocal textwidth=999' )
            vim.command( 'setfiletype vim_shell' )

            vim.command( 'au BufDelete ' + filename + ' :python lookup_buf( "' + filename + '" ).cleanup()' )

            ##  NOTE: This one does not have <silent> because it causes weird behavior w/ the cursor
            vim.command( 'inoremap <buffer> <CR> <ESC>:python lookup_buf( "' + filename + '" ).execute_cmd()<CR>' )

            vim.command( 'inoremap <silent> <buffer> ' + timeout_key + ' <ESC>:python lookup_buf( "' + filename + '" ).set_timeout()<CR>' )
            vim.command( 'nnoremap <silent> <buffer> ' + timeout_key + ' :python lookup_buf( "' + filename + '" ).set_timeout()<CR>' )

            vim.command( 'inoremap <silent> <buffer> ' + new_prompt_key + ' <ESC>:python lookup_buf ( "' + filename + '" ).new_prompt()<CR>' )
            vim.command( 'nnoremap <silent> <buffer> ' + new_prompt_key + ' :python lookup_buf( "' + filename + '" ).new_prompt()<CR>' )

            vim.command( 'inoremap <silent> <buffer> ' + page_output_key + ' <ESC>:python lookup_buf ( "' + filename + '" ).page_output()<CR>' )
            vim.command( 'nnoremap <silent> <buffer> ' + page_output_key + ' :python lookup_buf( "' + filename + '" ).page_output()<CR>' )
            vim.command( 'nnoremap <silent> <buffer> <CR> <ESC>:python lookup_buf( "' + filename + '" ).page_output()<CR>' )

            vim.command( 'inoremap <silent> <buffer> ' + intr_signal_key + ' <ESC>:python lookup_buf ( "' + filename + '" ).send_intr()<CR>' )
            vim.command( 'nnoremap <silent> <buffer> ' + intr_signal_key + ' :python lookup_buf( "' + filename + '" ).send_intr()<CR>' )

            vim.command( 'inoremap <silent> <buffer> ' + clear_key + ' <ESC>:python lookup_buf ( "' + filename + '" ).clear_screen( True )<CR>')
            vim.command( 'nnoremap <silent> <buffer> ' + clear_key + ' :python lookup_buf( "' + filename + '").clear_screen( False )<CR>' )

            if g_use_pty:
                vim.command( 'inoremap <silent> <buffer> ' + eof_signal_key + ' <ESC>:python lookup_buf ( "' + filename + '" ).send_eof()<CR>' )
                vim.command( 'nnoremap <silent> <buffer> ' + eof_signal_key + ' :python lookup_buf( "' + filename + '" ).send_eof()<CR>' )

            return 0

        else:

            dbg_print( 'new_buf: file ' + filename + ' exists' )

            vim.command( 'edit ' + filename )
            return 1

    except:

        dbg_print( 'new_buf: exception!' + str( sys.exc_info()[0] ) )

################################################################################

def spawn_buf( _filename ):

    exists = new_buf( _filename )

    if not exists:      ##  has a shell been created for the buffer yet??

        dbg_print( 'spawn_buf: buffer doesn\'t exist so creating a new one' )
        
        cur = vim.current.buffer

        ##  Make vimsh associate buffer with _filename and add to list of buffers
        vim_shell = vimsh( sh, arg, _filename )

        g_buffers.append( ( _filename, vim_shell ) )

        vim_shell.setup_pty( g_use_pty )

        vim_shell.read( cur )
        cur_line, cur_row = vim_shell.get_vim_cursor_pos()

        ##  last line *should* be prompt, tuck it away for syntax hilighting
        hi_prompt = cur[ cur_line - 1 ]

    else:

        dbg_print( 'main: buffer does exist' )
        vim.command( 'normal G$' )
        vim_shell = lookup_buf( _filename )

    vim.command( 'startinsert!' ) 

################################################################################

def lookup_buf( _filename ):

    for key, val in g_buffers:

        if key == _filename:

            dbg_print( 'lookup_buf: found match ' + str( val ) )
            return val

    dbg_print( 'lookup_buf: couldn\'t find match for ' + _filename )

    return None

################################################################################

def remove_buf( _filename ):

    dbg_print ( 'remove_buf: looking for ' + _filename + ' to remove from buffer list' )

    idx = 0

    for key, val in g_buffers:

        if key == _filename:
            break

        idx = idx + 1

    if ( len( g_buffers ) >= idx ) and ( len( g_buffers ) != 0 ):

        dbg_print ( 'remove_buf: removing buffer from list at index ' + str( idx ) )
        del g_buffers[ idx ]

################################################################################

if ( g_init_ok ):     ##  Only set this up if all modules were imported ok

    ############################# customization ###################################
    #
    #  Don't edit the lines below, instead set the g:<variable> in your
    #  .vimrc to the value you would like to use.  For numeric settings
    #  *DO NOT* put quotes around them.  The quotes are only needed in
    #  this script.  See vimsh.readme for more details
    #
    ###############################################################################

    ##  Allow pty prompt override, useful if you have an ansi prompt, etc
    #

    prompt_override = int( test_and_set( 'g:vimsh_pty_prompt_override', '1' ) )

    ##  Prompt override, used for pty enabled.  Just use a very simple prompt
    ##  and make no definitive assumption about the shell being used if
    ##  vimsh_prompt_pty is not set.  This will only be used if
    ##  vimsh_pty_prompt_override (above) is 1.
    ##
    ##  NOTE: [t]csh doesn't use an environment variable for setting the prompt so setting 
    ##        an override prompt will not work.
    #

    if g_use_pty:
        if prompt_override:
            new_prompt = test_and_set( 'g:vimsh_prompt_pty', r'> ' )

            os.environ['prompt'] = new_prompt
            os.environ['PROMPT'] = new_prompt
            os.environ['PS1']    = new_prompt

    ##  shell program and supplemental arg to shell.  If no supplemental
    ##  arg, just use ''
    #

    if sys.platform == 'win32':
        sh  = test_and_set( 'g:vimsh_sh',     'cmd.exe' )       # NT/Win2k
        arg = test_and_set( 'g:vimsh_sh_arg', '-i' )            

    else:    

        try:
            user_shell = os.environ['SHELL']

        except:

            dbg_print( 'main: Using default /bin/sh' )
            user_shell = '/bin/sh'

        dbg_print( 'main: user_shell is ' + user_shell )

        sh  = test_and_set( 'g:vimsh_sh',     'foobar' )       # Unix
        arg = test_and_set( 'g:vimsh_sh_arg', '-i' )

        if sh == 'foobar':
            ##  user did not override which this takes precedence over $SHELL
            sh = user_shell

    ##  clear shell command behavior
    #  0 just scroll for empty screen
    #  1 delete contents of buffer
    #

    clear_all  = test_and_set( 'g:vimsh_clear_all', '0' )
                                    
    ##  new vimsh window behavior
    #  0 use current buffer if not modified
    #  1 always split
    #

    split_open = test_and_set( 'g:vimsh_split_open', '1' )

    ##  show helpful (hopefully) messages, mostly for issues that aren't resolved but
    ##  have workarounds
    #  0 don't show them, you know what your doing
    #  1 show them
    #

    show_workaround_msgs = test_and_set( 'g:vimsh_show_workaround_msgs', '1' )

    ##  Prompts for the timeouts for read( s )
    #
    #      set low for local usage, higher for network apps over slower link
    #      0.1 sec is the lowest setting
    #      over a slow link ( 28.8 ) 1+ seconds works well
    #

    timeout_key = test_and_set( 'g:vimsh_timeout_key', '<F3>' )

    ##  Create a new prompt at the bottom of the buffer, useful if stuck.
    ##  Please try to give me a bug report of how you got stuck if possible.

    new_prompt_key = test_and_set( 'g:vimsh_new_prompt_key', '<F4>' )

    ##  If output just stops, could be because of short timeouts, allow a key
    ##  to attempt to read more, rather than sending the <CR> which keeps
    ##  spitting out prompts.

    page_output_key = test_and_set( 'g:vimsh_page_output_key', '<F5>' )

    ##  Send a process SIGINT (INTR) (usually control-C)

    intr_signal_key = test_and_set( 'g:vimsh_intr_key', '<C-c>' )

    ##  Send a process EOF (usually control-D) python needs it to
    ##  quit interactive shell.

    eof_signal_key = test_and_set( 'g:vimsh_eof_key', '<C-d>' )

    ##  Clear screen

    clear_key = test_and_set( 'g:vimsh_clear_key', '<C-l>' )

    ############################ end customization #################################
